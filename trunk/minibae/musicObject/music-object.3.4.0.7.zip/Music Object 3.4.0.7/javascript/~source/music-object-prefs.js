/**********
     TITLE: Music Object Preferences
   VERSION: 1.0.1
      TYPE: Shared Code
    AUTHOR: Chris van Rensburg
 COPYRIGHT: 1996-2001 Beatnik, Inc. All Rights Reserved
  REQUIRES: music-object.js
**********/

Music.debugToJavaConsole = true;
Music.debugToAlert = false;
Music.debugToStatus = false;
Music.showCompatibilityPrompt = false;

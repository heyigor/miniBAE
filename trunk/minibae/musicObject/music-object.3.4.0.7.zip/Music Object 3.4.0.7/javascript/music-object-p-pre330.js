/**********
     TITLE: Music Object Patch - Pre 3.3.0
   VERSION: 1.0.0
    AUTHOR: Chris van Rensburg
 COPYRIGHT: 1996-2001 Beatnik, Inc. All Rights Reserved
  REQUIRES: music-object.js (3.3.0 or higher)
**********/
mo_addEventHandler=Music.addEventHandler;mo_addInstanceMethods=mo_addPublicInstanceMethods=Music.addPublicInstanceMethods;mo_addInstanceExtender=Music.addInstanceExtender;mo_addPrivateMethods=mo_addPrivateInstanceMethods=Music.addPrivateInstanceMethods;mo_addStaticMethods=mo_addPublicStaticMethods=Music.addPublicStaticMethods;mo_addSupportedClient=Music.addSupportedClient;mo_checkForPlayer=Music.checkForPlayer;mo_execHandler=Music.execHandler;mo_globalThru=Music.globalThru;mo_indexOf=Music.indexOf;mo_isInstance=Music.isInstance;mo_kill=Music.kill;mo_meetsMinVersion=Music.meetsMinVersion;mo_null=Music.doNothing;mo_openWindow=Music.openWindow;mo_parseAttributes=Music.parseAttributes;mo_retrieveVersion=Music.retrieveVersion;mo_stringHasAny=Music.stringHasAny;mo_tagAttr=Music.tagAttr;
mo_wireInstanceMethod=Music.wireMethod;